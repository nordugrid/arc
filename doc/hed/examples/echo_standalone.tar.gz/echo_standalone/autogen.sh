#!/bin/sh
#

autoreconf --verbose --force --install
